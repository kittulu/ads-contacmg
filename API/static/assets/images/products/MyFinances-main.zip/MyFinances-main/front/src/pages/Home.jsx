// import * as React from 'react';
// import { createDrawerNavigator } from '@react-navigation/drawer';
// import { NavigationContainer } from '@react-navigation/native';
// import Main from './Main';

// const Drawer = createDrawerNavigator();

// export default function Home() {
//   return (
      
//   );
// }
