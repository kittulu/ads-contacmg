package com.unesc.myfinances;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfinancesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfinancesApplication.class, args);
	}

}
